#!/usr/bin/env bash
java -jar mvn-repo-cleaner.jar